import {build} from 'esbuild';
import {readFile,writeFile,readdir} from 'node:fs/promises';
const embedded=new Map();
for(const dir of ['members','signatures'])for(const file of (await readdir('site/'+dir)).filter(f=>/\.(png|webp)$/.test(f))){
 const mime=file.endsWith('.webp')?'image/webp':'image/png';
 embedded.set('/'+dir+'/'+file,'data:'+mime+';base64,'+(await readFile('site/'+dir+'/'+file)).toString('base64'));
}
const alias={'@':new URL('./src',import.meta.url).pathname,'next/image':new URL('./src/image.tsx',import.meta.url).pathname,'next/navigation':new URL('./src/navigation.ts',import.meta.url).pathname};
const output=await build({entryPoints:['src/preview-client.tsx'],bundle:true,minify:true,write:false,format:'iife',target:['es2022'],alias,define:{'process.env.NODE_ENV':'"production"'},jsx:'automatic',plugins:[{name:'embed-face-assets',setup(b){b.onLoad({filter:/src\/(lib\/members|lib\/profiles)\.ts$/},async args=>{let contents=await readFile(args.path,'utf8');for(const [url,value] of embedded)contents=contents.replaceAll(url,value);return {contents,loader:'ts'};});}}]});
let html=await readFile('site/index.html','utf8');
for(const [url,value] of embedded)html=html.replaceAll(url,value);
const styles=(await readFile('site/assets/styles.css','utf8'))+'\n'+await readFile('site/assets/independent.css','utf8');
html=html.replace(/<link rel="stylesheet"[^>]*>/g,'').replace(/<script[^>]*src="[^"]*"[^>]*><\/script>/g,'');
html=html.replace('<title>','<title>미리보기 · ').replace('</head>',`<style>${styles}</style></head>`);
html=html.replace('</body>',`<script>${output.outputFiles[0].text.replaceAll('</script','<\\/script')}</script></body>`);
// Keep the icon local to this file, too.
html=html.replace('href="/favicon.svg"','href="data:image/svg+xml;base64,'+(await readFile('site/favicon.svg')).toString('base64')+'"');
await writeFile('mokkomokko-preview.html',html);
console.log('Created self-contained offline preview with four faces and eight signatures.');
