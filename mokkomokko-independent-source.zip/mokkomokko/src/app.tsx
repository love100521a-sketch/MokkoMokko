import {useEffect,useSyncExternalStore} from 'react';
import Home from './home';
import MemberPage from './member-page';
import Album from './album';
import Login from './login';
import Manage from './manage';
import {AuthProvider} from './auth';
import {getBackend} from './backend';
import {getMember} from './lib/members';
import {validateProfile,type Profile} from './lib/profiles';
import {applyProfiles,profileVersion,subscribeProfiles} from './lib/profile-store';
export function App({path}:{path:string}){
 useSyncExternalStore(subscribeProfiles,profileVersion,()=>0);
 useEffect(()=>{
  const db=getBackend();if(!db)return;
  db.from('profiles').select('slug,data').then(({data,error})=>{
   if(error)return;const result:Record<string,Profile>={};
   for(const row of data??[]){const profile=validateProfile(row.data);if(getMember(row.slug)&&profile)result[row.slug]=profile;}
   applyProfiles(result);
  });
 },[]);
 const segments=path.split('/').filter(Boolean);
 let page;
 if(!segments.length)page=<Home/>;
 else if(segments[0]==='login')page=<Login/>;
 else if(segments[0]==='manage')page=<Manage/>;
 else if(segments[0]==='members'&&getMember(segments[1]))page=segments[2]==='album'?<Album slug={segments[1]}/>:<MemberPage params={{slug:segments[1]}}/>;
 else page=<main className="manage-shell"><section className="access-card"><div className="access-icon">✳</div><h1>길을 잃었나요?</h1><p>모꼬모꼬의 작은 놀이터로 돌아가요.</p><a className="solid-link" href="/">홈으로 이동 →</a></section></main>;
 return <AuthProvider>{page}</AuthProvider>;
}
