import Image from "next/image";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, ArrowUpRight, Images, UserRound, Sparkles } from "lucide-react";
import { getMember, members } from "@/lib/members";
import { readProfile } from '@/lib/profile-store';
import ProfileDetails from '@/components/profile-details';

export const dynamic='force-dynamic';
export function generateStaticParams() { return members.map(({slug}) => ({slug})); }
const rooms:Record<string,{label:string;heading:string;note:string}>={
 kkongaji:{label:'PINK FOX ROOM',heading:'아랑이와 함께하는 핑크빛 공간',note:'아지의 소개부터 함께 남긴 기록까지, 한 곳에 모았어요.'},
 momongtto:{label:'BUBBLE ALCHEMY ROOM',heading:'비누방울처럼 반짝이는 모몽또의 공간',note:'모몽또의 프로필을 만나고, 팬들이 남긴 그림도 한 장씩 꺼내 보세요.'},
 heundong:{label:'OCEAN CAT ROOM',heading:'검정과 바다빛이 만나는 흰동의 공간',note:'흰동의 소개와 추억을 담은 팬아트 앨범을 만나보세요.'},
 mimya:{label:'WARM PUPPY ROOM',heading:'반가운 마음으로 찾아온 밈먀의 공간',note:'밈먀의 이야기를 읽고, 팬아트에 담긴 마음도 함께 구경해요.'},
};
export default function MemberPage({params}:{params:{slug:string}}) {
 const {slug}=params;const member=getMember(slug);if(!member)notFound();
 const profile=readProfile(slug),room=rooms[slug];
 const memberIndex=members.findIndex(m=>m.slug===slug),previous=members[(memberIndex+3)%4],next=members[(memberIndex+1)%4];
 const style={"--member-color":member.color,"--member-soft":member.soft,"--member-ink":member.ink} as React.CSSProperties;
 return <main key={slug} className={`member-shell personal-shell theme-${slug} page-reveal`} style={style}>
  <nav className="member-nav" aria-label="멤버 탐색"><a className="back-link" href="/"><ArrowLeft size={17}/> 모꼬모꼬 홈</a><a className="wordmark" href="/">MOKKOMOKKO<i>✳</i></a></nav>
  <div className="personal-masthead"><span className="room-label"><span/>{room.label}</span><div className="personal-entry-title">{member.name}의 개인 페이지 <span aria-hidden="true">{member.symbol}</span></div><p>모꼬모꼬의 {memberIndex+1}번째 색, {member.name}의 공간에 오신 걸 환영해요.</p><span className="room-stamp">PLAYER 0{memberIndex+1}<br/>MOKKOMOKKO</span></div>
  <nav className="personal-tabs" aria-label={`${member.name} 개인 페이지 메뉴`}><span className="personal-tabs-name">{member.symbol} {member.name}</span><a href="#about">소개</a><a href="#profile">프로필</a><a href={`/members/${slug}/album`}>팬아트 앨범 <ArrowUpRight size={13}/></a><a href="#member-rooms">다른 멤버</a></nav>
  <section className="member-hero" id="about" aria-labelledby="member-name">
   <div className="personal-portrait-wrap"><div className="member-portrait"><Image src={member.image} alt={member.name+" 얼굴"} fill sizes="(max-width: 650px) 100vw, 50vw" priority/></div><span className="portrait-caption">{member.english} <b>✳ MOKKOMOKKO</b></span><span className="portrait-orbit orbit-one" aria-hidden="true"/><span className="portrait-orbit orbit-two" aria-hidden="true"/></div>
   <div className="member-copy"><span className="micro-label">MEET THE MEMBER / {member.symbol} {profile.rp}</span><h1 id="member-name">{member.name}</h1><div className="english">{member.english}</div><h2>{profile.intro}</h2><p className="preserve-lines">{profile.details}</p><div className="chips"><span>RP · {profile.rp}</span><span>MBTI · {profile.mbti}</span></div><div className="personal-hero-actions"><a className="solid-link" href={`/members/${slug}/album`}><Images size={18}/> {member.name} 앨범 열기 <ArrowUpRight size={16}/></a><a className="personal-text-action" href="#profile">프로필 읽기 ↓</a></div></div>
  </section>
  <section className="personal-passport" id="profile" aria-labelledby="passport-title"><div className="passport-intro"><div className="section-kicker"><UserRound size={14}/> MY PLAYER CARD</div><h2 id="passport-title">{member.name} 프로필</h2><p>{room.heading}</p></div><dl className="passport-facts"><div><dt>이름</dt><dd>{member.name}</dd></div><div><dt>RP</dt><dd>{profile.rp}</dd></div><div><dt>MBTI</dt><dd>{profile.mbti}</dd></div><div><dt>시그니처 컬러</dt><dd><span className="personal-swatches"><i style={{background:member.color}}/>{slug==='heundong'&&<i style={{background:'#172332'}}/>}<span>{member.symbol} {member.english}</span></span></dd></div></dl></section>
  <ProfileDetails profile={profile} slug={slug}/>
  <section className="personal-album-door" aria-labelledby="personal-album-title"><div className="album-door-art" aria-hidden="true"><div className="album-paper paper-back"/><div className="album-paper paper-front"><Image src={member.image} alt="" fill sizes="170px"/></div><span>{member.symbol}</span></div><div className="album-door-copy"><div className="section-kicker"><Sparkles size={14}/> A LITTLE ARCHIVE OF LOVE</div><h2 id="personal-album-title">{member.name}의 팬아트 앨범</h2><p>{room.note}</p><a className="solid-link" href={`/members/${slug}/album`}>{member.name} 앨범으로 이동 <ArrowRight size={18}/></a></div></section>
  <section className="personal-other-rooms" id="member-rooms" aria-labelledby="other-rooms-title"><div className="room-section-heading"><div><div className="section-kicker">NEXT PLAYER</div><h2 id="other-rooms-title">다른 멤버의 공간도 만나볼까요?</h2></div><a href="/">모든 멤버 보기 ↗</a></div><nav className="personal-roster" aria-label="멤버 개인 페이지">{members.map(item=><a key={item.slug} href={`/members/${item.slug}`} aria-current={item.slug===slug?'page':undefined} className={item.slug===slug?'current-room':''} style={{'--tile-color':item.color,'--tile-soft':item.soft} as React.CSSProperties}><div className="room-avatar"><Image src={item.image} alt="" fill sizes="58px"/></div><div><strong>{item.name}</strong><span>{item.slug===slug?'지금 보고 있는 공간':'개인 페이지로 이동'}</span></div><ArrowUpRight size={18}/></a>)}</nav></section>
  <nav className="personal-pagination" aria-label="이전 다음 멤버"><a href={`/members/${previous.slug}`}><ArrowLeft size={19}/><span><small>이전 멤버</small><strong>{previous.name}</strong></span></a><span className="player-count">0{memberIndex+1} <i>/</i> 04</span><a href={`/members/${next.slug}`}><span><small>다음 멤버</small><strong>{next.name}</strong></span><ArrowRight size={19}/></a></nav>
  <footer className="personal-footer"><span>© MOKKOMOKKO · {member.english}</span><a href="/manage">멤버 로그인 · 내 정보 관리 ↗</a></footer>
 </main>;
}
