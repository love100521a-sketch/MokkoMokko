import {defaultProfile,type Profile} from './profiles';
const saved:Record<string,Profile>={};
const listeners=new Set<()=>void>();
let version=0;
export const readProfile=(slug:string)=>saved[slug]??defaultProfile(slug);
export function applyProfiles(profiles:Record<string,Profile>){Object.assign(saved,profiles);version++;listeners.forEach(fn=>fn());}
export const profileVersion=()=>version;
export function subscribeProfiles(fn:()=>void){listeners.add(fn);return ()=>{listeners.delete(fn);};}
