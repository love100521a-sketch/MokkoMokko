export type Member = {
  slug: string; name: string; english: string; rp: string; mbti: string;
  color: string; soft: string; ink: string; image: string;
  symbol: string; intro: string; details: string;
};

export const members: Member[] = [
  { slug:"kkongaji", name:"꽁아지", english:"KKONG-AJI", rp:"핑크여우", mbti:"ESTP", color:"#f267a0", soft:"#ffe1ed", ink:"#8a2453", image:"/members/kkong-face.webp", symbol:"✦", intro:"장난기 넘치는 핑크여우", details:"분홍빛 머리와 반짝이는 푸른 눈. 재빠른 발걸음으로 모꼬모꼬의 새로운 놀이를 먼저 찾아내는 멤버예요." },
  { slug:"momongtto", name:"모몽또", english:"MOMONG-TTO", rp:"비누방울 고양이 연금술사", mbti:"E(I)NFP", color:"#8bcbe6", soft:"#e2f7ff", ink:"#306d91", image:"/members/momong-face.webp", symbol:"◌", intro:"비누방울 고양이 연금술사", details:"비누방울처럼 반짝이는 모몽또의 공간에 오신 것을 환영해요. 프로필과 팬아트 앨범을 만나보세요." },
  { slug:"heundong", name:"흰동", english:"HEUN-DONG", rp:"고양이", mbti:"INFP", color:"#147fae", soft:"#d5f2fb", ink:"#102b43", image:"/members/heundong-face.webp", symbol:"✳", intro:"푸른 바다빛을 품은 고양이", details:"검정과 코발트블루가 만나는 단발, 푸른 눈과 작은 물고기 뼈 핀. 조용하지만 마음속엔 커다란 바다가 있는 멤버예요." },
  { slug:"mimya", name:"밈먀", english:"MIM-MYA", rp:"시고르자브종 누렁이", mbti:"ESFJ", color:"#edb85f", soft:"#fff0cf", ink:"#8a571e", image:"/members/mimya-face.webp", symbol:"✿", intro:"따뜻한 크림빛의 동네 친구", details:"크림색 단발과 살구빛 앞머리, 맑은 청록색 눈. 먼저 다가와 반갑게 맞아 주는 모꼬모꼬의 다정한 누렁이예요." },
];

export const getMember = (slug: string) => members.find((member) => member.slug === slug);
