import { getMember } from './members';

export type Profile = {
  intro: string; details: string; rp: string; mbti: string;
  facts: {label:string;value:string}[]; likes:string; dislikes:string;
  broadcast:string; fandom:string; subscription:string; schedule:string; content:string;
  models:string; names:string; history:string;
};

export const signatures = [
  {url:'/signatures/kkong-3.png',label:'아지야',number:'57'},
  {url:'/signatures/kkong-1.png',label:'예쁜 우리 아지',number:'157'},
  {url:'/signatures/kkong-2.png',label:'생일 축하해',number:'331'},
  {url:'/signatures/kkong-4.png',label:'사랑해 아지',number:'457'},
  {url:'/signatures/kkong-5.png',label:'천사 아지',number:'1457'},
  {url:'/signatures/kkong-6.png',label:'예쁜 아지',number:'2857'},
  {url:'/signatures/kkong-7.png',label:'오직 아지',number:'5757'},
  {url:'/signatures/kkong-8.png',label:'많이 사랑해 아지',number:'12457'},
];

const emoteRoot='https://static.file.sooplive.com/signature_emoticon/azi1253/';
export const emoticons = [
 ['ggkk','65486738d6d31b8aa.png'],['ggmm','72506738d6e6412cc.png'],['gguu','60846738d70add9e1.png'],['gglp','20696738d71da2695.png'],['gght','45736738d74540f90.png'],['ggba','82156738bc0e61c74.png'],['ggbam','61686738bc1a76e99.png'],['ggbo','87096738bc26bb15c.png'],['gggg','47836738bc44829a4.png'],['ggha','96856738bc4d48cde.png'],['ggee','25156744014996023.png'],
 ['아지꽝','45866879224ef0de6.webp'],['아지낼름','86506879233fc47fb.webp'],['아지멍','636568792365e4b95.webp'],['아랑이화남','2214687923b383a36.webp'],['아랑이춤','36986879268dd1298.webp'],['아랑이춤2','6923687926aa00482.webp'],
].map(([name,file])=>({name,url:emoteRoot+file}));

export function defaultProfile(slug:string):Profile {
 const m=getMember(slug)!;
 const base:Profile={intro:m.intro,details:m.details,rp:m.rp,mbti:m.mbti,facts:[],likes:'',dislikes:'',broadcast:'',fandom:'',subscription:'',schedule:'',content:'',models:'',names:'',history:''};
 if(slug!=='kkongaji')return base;
 return {...base,intro:'🩷 꽁아지ぐ 🩷',details:'댕청함 70% / 털털함 30%\n혀짧고 징징거리는 핑크여우, 아랑이들과 함께 놀아요.',
 facts:[{label:'나이',value:'영원한 24살'},{label:'생일',value:'3월 31일'},{label:'성별',value:'여자'},{label:'종족',value:'핑크여우'},{label:'MBTI',value:'ESTP (근데 울보임)'},{label:'키',value:'162~5?ㅋㅎ'},{label:'몸무게',value:'비밀이라하고맨날얘기하기'},{label:'성격',value:'댕청함 70% / 털털함 30%'},{label:'특징',value:'혀짧고 징징거리기'},{label:'특기',value:'오빵이들 홀리기 / 답답하게 해서 힘들게하기 ^3^'}],
 likes:'아랑이(팬들)\n날 좋아해주는 사람',dislikes:'아랑이가 없는 삶\n날 싫어하는 사람',
 broadcast:'치지직 · 2024년 2월 22일\nSOOP · 2024년 11월 19일\n베스트 스트리머 · 2025년 7월 31일',
 fandom:'아랑이',subscription:'구독닉변: ぐ\n(아지의 송곳니로 여러분을 앙 문다요!!)\n구독티콘: 베이직 / 플러스',
 schedule:'월요일 정기 휴방\n월요일에 못 쉴 경우 수요일로 대체',content:'종합 게임\n쿠소 + 리듬게임 절대불가',
 models:'2025.02.01 · (VSF) 뉴 꽁아지 2.0\n2025.06.06 · (와루도) 꽁아지 2.5\n2025.12.21 · (와루도프로) 닐로툰 아지',
 names:'2024.11.19 ~ 2025.12.08 · 꽁아지♡\n2025.12.08 ~ 2026.03.11 · 아지ぐ\n2026.03.12 ~ · 꽁아지ぐ 활동중',
 history:'마카오톡 1.5/1.75 완주\n오아 : 샌박을 잡아라\n블랙워크 : 핫드롭 대회\n퍼켓몬 서버\n린코 레일\n야.너.다 서버 (다이아서버) 클리어\n뉴냥이 발로란트 발린이 CK 2회차 우승\n프리블록스 배틀로얄 스트리머 대전 2등\n최또님 발로란트 시발대 얏밥대전 우승\n꾸다방 서버 (다이아서버) 클리어\nAKL 참가! (꼴등팀 2번만든이력)\n수피님 숲바꼭질 도망자 우승\n뉴냥이 발로란트 발린이 CK 5회차 우승\n레오펠 걸뱅이!!\n포트나이트 손흥민 100 개인전 3등\n빙밍님 Summer heat 4R 가족오락관 1등\n(숲) 꾸산당 1,2기 합격 및 활동\n마령전\n연습서버 완주\n봄세이님 크루대전2 4라운드 우승\n봄세이님 크루대전3 1라운드 우승\n딩딩이 다이아랜딩 서버 졸업\n홍창의 숲\n쓔배교 듀오 킬내기 우승\n중력님 마크배그 (아칸팀) 우승\n정다니 다케론서버 베타 딜량 3위'};
}

const textKeys=['intro','details','rp','mbti','likes','dislikes','broadcast','fandom','subscription','schedule','content','models','names','history'] as const;
export function validateProfile(value:unknown):Profile|null {
 if(!value||typeof value!=='object'||Array.isArray(value))return null;
 const v=value as Record<string,unknown>, out:Record<string,unknown>={};
 for(const k of textKeys){if(typeof v[k]!=='string'||(v[k] as string).length>(k==='history'?12000:3000))return null;out[k]=(v[k] as string).trim();}
 if(!out.intro||!out.rp||!out.mbti||!Array.isArray(v.facts)||v.facts.length>20)return null;
 const facts=[];
 for(const f of v.facts){if(!f||typeof f.label!=='string'||typeof f.value!=='string'||f.label.length>40||f.value.length>400)return null;facts.push({label:f.label.trim(),value:f.value.trim()});}
 return {...out,facts} as Profile;
}
