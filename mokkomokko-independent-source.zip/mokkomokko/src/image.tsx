import type {ImgHTMLAttributes, CSSProperties} from 'react';
type Props=ImgHTMLAttributes<HTMLImageElement>&{fill?:boolean;priority?:boolean;unoptimized?:boolean};
export default function Image({fill,priority,unoptimized,...props}:Props){
 const style:CSSProperties=fill?{position:'absolute',inset:0,width:'100%',height:'100%',...props.style}:props.style??{};
 return <img {...props} style={style} loading={priority?'eager':props.loading??'lazy'}/>;
}
