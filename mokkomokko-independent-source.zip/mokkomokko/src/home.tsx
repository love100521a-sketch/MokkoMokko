import Image from "next/image";
import { ArrowUpRight, Gamepad2, Images, Sparkles } from "lucide-react";
import { members } from "@/lib/members";
import {readProfile} from '@/lib/profile-store';
export const dynamic='force-dynamic';

export default function Home() {
  const roster=members.map(m=>({...m,rp:readProfile(m.slug).rp}));
  return (
    <main className="site-shell home-shell page-reveal">
      <header className="topbar">
        <a className="wordmark" href="/" aria-label="모꼬모꼬 홈">M<span>O</span>K<span>K</span>O<span>M</span>O<span>K</span>K<span>O</span><i>✳</i></a>
        <div className="topbar-right"><span>우리의 작은 놀이터</span><a className="member-login" href="/manage">멤버 로그인 ↗</a><Gamepad2 size={20} aria-hidden="true" /></div>
      </header>

      <section className="home-intro" aria-labelledby="home-title">
        <div className="eyebrow"><span className="eyebrow-dot" /> CLUB MOKKOMOKKO · 4 PLAYERS</div>
        <h1 id="home-title" aria-label="모꼬모꼬"><span className="brand-letter">모</span><span className="brand-letter">꼬</span><span className="brand-letter">모</span><span className="brand-letter">꼬</span><span className="title-star" aria-hidden="true">✳</span></h1>
        <p>네 가지 색, 네 가지 이야기. 마음에 드는 멤버를 눌러 만나보세요.</p>
      </section>

      <section className="console" aria-label="모꼬모꼬 멤버 선택">
        <div className="console-top"><span><span className="power-light" /> POWER ON</span><span>HANDHELD CLUB · 01</span></div>
        <div className="console-screen">
          <div className="screen-head"><span>SELECT PLAYER</span><span>01 — 04</span></div>
          <div className="member-grid">
            {roster.map((member, index) => (
              <a key={member.slug} href={`/members/${member.slug}`} aria-label={`${member.name} 개인 페이지로 이동`} className={`member-card theme-${member.slug}`} style={{"--member-color":member.color,"--member-soft":member.soft} as React.CSSProperties}>
                <span className="member-num">0{index + 1} / PROFILE</span>
                <div className="member-image"><Image src={member.image} alt={`${member.name} 얼굴`} fill sizes="(max-width: 700px) 45vw, 220px" priority={index < 2} /></div>
                <div className="member-info"><span><strong>{member.name}</strong><small>{member.rp}</small></span><ArrowUpRight size={22} aria-hidden="true" /></div><div className="member-card-enter">개인 페이지 입장 <span aria-hidden="true">→</span></div>
              </a>
            ))}
          </div>
          <div className="screen-bottom"><span>✳ 클릭해서 입장하기</span><span>모꼬모꼬</span></div>
        </div>
        <div className="console-controls"><div className="dpad" aria-hidden="true"><span>＋</span></div><div className="control-note">오늘은 누구와 놀까요?</div><div className="ab-buttons" aria-hidden="true"><span>B</span><span>A</span></div></div>
      </section>

      <section className="home-album" aria-labelledby="album-heading">
        <div><div className="section-kicker"><Sparkles size={15} /> FAN ART ARCHIVE</div><h2 id="album-heading">우리만의 앨범</h2><p>멤버에게 전한 마음을 모아, 한 장씩 꺼내 보는 공간.</p></div>
        <div className="album-shortcuts">{members.map((member) => <a key={member.slug} href={`/members/${member.slug}/album`} style={{"--member-color":member.color} as React.CSSProperties}><Images size={17} />{member.name}<ArrowUpRight size={16} /></a>)}</div>
      </section>
      <footer className="site-footer"><span>© MOKKOMOKKO CLUB</span><span>PLAY TOGETHER, STAY TOGETHER ✳</span></footer>
    </main>
  );
}
