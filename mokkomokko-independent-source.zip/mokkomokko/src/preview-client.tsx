import {createRoot} from 'react-dom/client';
import {useEffect,useState} from 'react';
import {App} from './app';
function Preview(){
 const [path,setPath]=useState('/');
 useEffect(()=>{
  function route(){if(location.hash.startsWith('#/')){setPath(decodeURI(location.hash.slice(1)));window.scrollTo(0,0);}}
  function click(event:MouseEvent){
   if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
   const anchor=(event.target as Element)?.closest('a');const href=anchor?.getAttribute('href');
   if(!href?.startsWith('/')||href.startsWith('//'))return;
   event.preventDefault();location.hash=href;if(path===href)window.scrollTo(0,0);
  }
  route();window.addEventListener('hashchange',route);document.addEventListener('click',click);
  return ()=>{window.removeEventListener('hashchange',route);document.removeEventListener('click',click);};
 },[path]);
 return <App key={path} path={path}/>;
}
createRoot(document.getElementById('app')!).render(<Preview/>);
