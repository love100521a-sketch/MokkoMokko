import {createContext,useContext,useEffect,useState,type ReactNode} from 'react';
import type {User} from '@supabase/supabase-js';
import {getBackend} from './backend';
import {getMember} from './lib/members';
type Auth={ready:boolean;configured:boolean;user:User|null;own:string|null;error:string;refresh:()=>Promise<void>};
const Context=createContext<Auth>({ready:false,configured:false,user:null,own:null,error:'',refresh:async()=>{}});
export const useAuth=()=>useContext(Context);
export function AuthProvider({children}:{children:ReactNode}){
 const [state,setState]=useState<Omit<Auth,'refresh'>>({ready:false,configured:false,user:null,own:null,error:''});
 async function refresh(){
  const db=getBackend();if(!db){setState({ready:true,configured:false,user:null,own:null,error:''});return;}
  const {data,error}=await db.auth.getUser();
  if(error||!data.user){setState({ready:true,configured:true,user:null,own:null,error:''});return;}
  const role=await db.from('member_editors').select('member_slug').eq('user_id',data.user.id).maybeSingle();
  const own=role.data&&getMember(role.data.member_slug)?role.data.member_slug:null;
  setState({ready:true,configured:true,user:data.user,own,error:role.error?'편집 권한을 확인하지 못했어요. 잠시 후 다시 로그인해 주세요.':''});
 }
 useEffect(()=>{
  void refresh();const db=getBackend();
  // Defer queries until the SDK releases its authentication lock.
  const subscription=db?.auth.onAuthStateChange(()=>{setTimeout(()=>{void refresh();},0);});
  return ()=>subscription?.data.subscription.unsubscribe();
 },[]);
 return <Context.Provider value={{...state,refresh}}>{children}</Context.Provider>;
}
