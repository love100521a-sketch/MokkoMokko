import {createClient,type SupabaseClient} from '@supabase/supabase-js';
declare global{interface Window{MOKKOMOKKO_CONFIG?:{supabaseUrl?:string;supabasePublishableKey?:string}}}
let client:SupabaseClient|null=null;
export function getBackend(){
 if(typeof window==='undefined')return null;
 if(client)return client;
 const c=window.MOKKOMOKKO_CONFIG;
 if(!c?.supabaseUrl||!c.supabasePublishableKey)return null;
 try{
  const url=new URL(c.supabaseUrl);
  if(url.protocol!=='https:')return null;
  // Only a publishable key belongs in a browser. Reject secret keys.
  if(c.supabasePublishableKey.startsWith('sb_secret_'))return null;
  const parts=c.supabasePublishableKey.split('.');
  if(parts.length===3){const claims=JSON.parse(atob(parts[1].replace(/-/g,'+').replace(/_/g,'/')));if(claims.role!=='anon')return null;}
  client=createClient(url.origin,c.supabasePublishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  return client;
 }catch{return null;}
}
