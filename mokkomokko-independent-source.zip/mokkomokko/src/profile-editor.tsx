"use client";
import {useState,type FormEvent} from 'react';
import {validateProfile,type Profile} from '@/lib/profiles';
import {getBackend} from './backend';
import {applyProfiles} from './lib/profile-store';
export default function ProfileEditor({slug,initial}:{slug:string;initial:Profile}){
 const [profile,setProfile]=useState(initial),[saving,setSaving]=useState(false),[message,setMessage]=useState('');
 const fields:[keyof Omit<Profile,'facts'>,string,boolean][]=[['intro','소개 제목',false],['details','소개글',true],['rp','RP · 종족 / 역할',false],['mbti','MBTI',false],['likes','좋아하는 것',true],['dislikes','싫어하는 것',true],['broadcast','방송 시작과 주요 날짜',true],['fandom','팬덤명',false],['subscription','구독 안내',true],['schedule','휴방과 방송 일정',true],['content','콘텐츠',true],['models','모델 변천사',true],['names','활동 이름 기록',true],['history','콘텐츠 참여 이력',true]];
 async function save(e:FormEvent){
 e.preventDefault();if(saving)return;const valid=validateProfile(profile);if(!valid){setMessage('필수 항목과 글자 수를 확인해 주세요.');return;}
 const db=getBackend();if(!db){setMessage('멤버 로그인을 준비 중이에요.');return;}
 setSaving(true);setMessage('');try{
 const {error}=await db.from('profiles').upsert({slug,data:valid},{onConflict:'slug'});if(error)throw error;
 setProfile(valid);applyProfiles({[slug]:valid});setMessage('저장했어요. 내 소개 페이지에 반영되었습니다.');
 }catch{setMessage('저장하지 못했어요. 내 멤버 계정인지 확인하고 다시 시도해 주세요.');}finally{setSaving(false);}
 }

 return <form className="editor-form" onSubmit={save}>
 <section className="profile-section"><h2>기본 소개</h2><div className="editor-grid">{fields.map(([key,label,multi])=><label key={key} className={multi?'wide':''}><span>{label}</span>{multi?<textarea rows={key==='history'?9:3} maxLength={key==='history'?12000:3000} value={profile[key]} onChange={e=>setProfile(p=>({...p,[key]:e.target.value}))}/>:<input maxLength={3000} required={['intro','rp','mbti'].includes(key)} value={profile[key]} onChange={e=>setProfile(p=>({...p,[key]:e.target.value}))}/>}</label>)}</div></section>
 <section className="profile-section"><h2>나의 프로필 항목</h2><p className="section-description">생일, 특기처럼 소개하고 싶은 내용을 추가해 주세요.</p>{profile.facts.map((f,i)=><div className="fact-editor" key={i}><label><span>항목 이름</span><input aria-label={`${i+1}번째 항목 이름`} maxLength={40} value={f.label} onChange={e=>setProfile(p=>({...p,facts:p.facts.map((a,n)=>n===i?{...a,label:e.target.value}:a)}))}/></label><label><span>내용</span><input aria-label={`${i+1}번째 항목 내용`} maxLength={400} value={f.value} onChange={e=>setProfile(p=>({...p,facts:p.facts.map((a,n)=>n===i?{...a,value:e.target.value}:a)}))}/></label><button type="button" className="remove-fact" onClick={()=>setProfile(p=>({...p,facts:p.facts.filter((_,n)=>n!==i)}))} aria-label={`${f.label||i+1} 항목 삭제`}>✕</button></div>)}<button type="button" className="outline-link" disabled={profile.facts.length>=20} onClick={()=>setProfile(p=>({...p,facts:[...p.facts,{label:'',value:''}]}))}>＋ 항목 추가</button></section>
 <div className="editor-save"><p role="status" aria-live="polite">{message}</p><button className="solid-link" disabled={saving} type="submit">{saving?'저장하는 중…':'변경 내용 저장'}</button></div>
 </form>;
}
