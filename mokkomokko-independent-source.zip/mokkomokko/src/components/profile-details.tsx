import {emoticons,type Profile} from '@/lib/profiles';
import SignatureGallery from './signature-gallery';
import {getMember} from '@/lib/members';
function Lines({value}:{value:string}){return <div className="profile-lines">{value.split('\n').filter(Boolean).map((line,i)=><p key={i}>{line}</p>)}</div>;}
export default function ProfileDetails({profile:p,slug}:{profile:Profile;slug:string}){
 const name=getMember(slug)?.name??'멤버';
 return <div className="profile-content">
 {p.facts.length>0&&<section className="profile-section"><div className="section-kicker">ABOUT ME</div><h2>{name}의 이야기</h2><dl className="fact-grid">{p.facts.map((f,i)=><div key={i}><dt>{f.label}</dt><dd>{f.value}</dd></div>)}</dl></section>}
 {(p.likes||p.dislikes)&&<div className="profile-two"><section className="profile-section"><div className="section-kicker">LOVE LIST</div><h2>🩷 좋아하는 것</h2><Lines value={p.likes}/></section><section className="profile-section"><div className="section-kicker">A LITTLE NOPE</div><h2>💔 싫어하는 것</h2><Lines value={p.dislikes}/></section></div>}
 {(p.broadcast||p.schedule||p.content)&&<section className="profile-section"><div className="section-kicker">ON AIR</div><h2>방송 이야기</h2><div className="profile-three">{p.broadcast&&<div><h3>방송의 시작</h3><Lines value={p.broadcast}/></div>}{p.schedule&&<div><h3>정기 휴방</h3><Lines value={p.schedule}/></div>}{p.content&&<div><h3>함께하는 콘텐츠</h3><Lines value={p.content}/></div>}</div></section>}
 {(p.fandom||p.subscription)&&<section className="profile-section"><div className="section-kicker">WITH YOU</div><h2>{p.fandom?`${p.fandom}와 함께`:'팬들과 함께'}</h2><Lines value={p.subscription}/></section>}
 {slug==='kkongaji'&&<><section className="profile-section"><div className="section-kicker">SUBSCRIBE EMOTICONS</div><h2>아랑이의 구독티콘</h2><p className="section-description">베이직 · 플러스 / 이미지를 누르면 원본이 열려요.</p><div className="emote-grid">{emoticons.map(e=><a href={e.url} key={e.name} target="_blank" rel="noopener noreferrer"><img src={e.url} alt={e.name} loading="lazy" referrerPolicy="no-referrer"/><span>/{e.name}/</span></a>)}</div><a className="text-link" href="https://ogqmarket.sooplive.com/?m=detail&productId=60e4506da101f" target="_blank" rel="noopener noreferrer">OGQ 스티커 보기 ↗</a></section><SignatureGallery/></>}
 {(p.models||p.names)&&<div className="profile-two">{p.models&&<section className="profile-section"><div className="section-kicker">AVATAR HISTORY</div><h2>모델 변천사</h2><Lines value={p.models}/></section>}{p.names&&<section className="profile-section"><div className="section-kicker">NAME ARCHIVE</div><h2>이름의 기록</h2><Lines value={p.names}/></section>}</div>}
 {p.history&&<section className="profile-section"><div className="section-kicker">PLAY HISTORY</div><h2>함께 남긴 기록</h2><p className="section-description">게임과 콘텐츠에서 쌓아 온 {name}의 이야기.</p><ul className="history-list">{p.history.split('\n').filter(Boolean).map((h,i)=><li key={i}><span>{String(i+1).padStart(2,'0')}</span>{h}</li>)}</ul></section>}
 </div>;
}
