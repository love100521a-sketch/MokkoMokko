"use client";
import {useRef,useState} from 'react';
import {signatures} from '@/lib/profiles';
export default function SignatureGallery(){
 const dialog=useRef<HTMLDialogElement>(null);const [selected,setSelected]=useState(0);
 const active=signatures[selected];
 return <section className="profile-section signature-section" aria-labelledby="signature-heading">
  <div className="section-kicker">SIGNATURE COLLECTION · 08</div><h2 id="signature-heading">아지의 시그니처</h2><p className="section-description">마음에 드는 이미지를 눌러 크게 보세요.</p>
  <div className="signature-grid">{signatures.map((s,i)=><button key={s.number} onClick={()=>{setSelected(i);dialog.current?.showModal();}} aria-label={`${s.label} ${s.number} 이미지 확대`}><img src={s.url} alt={`${s.label} · ${s.number}`} loading="lazy"/><span>{s.label}<b>{s.number}</b></span></button>)}</div>
  <dialog ref={dialog} className="signature-dialog" aria-label="시그니처 이미지 확대" onClick={e=>{if(e.target===e.currentTarget)dialog.current?.close();}}>
    <button className="dialog-close" onClick={()=>dialog.current?.close()} aria-label="확대 이미지 닫기">✕</button>
    <img src={active.url} alt={`${active.label} ${active.number}`}/><p>{active.label} · {active.number}</p>
    <div className="dialog-actions"><button onClick={()=>setSelected(i=>(i+7)%8)} aria-label="이전 시그니처">← 이전</button><span>{selected+1} / 8</span><button onClick={()=>setSelected(i=>(i+1)%8)} aria-label="다음 시그니처">다음 →</button></div>
  </dialog>
 </section>;
}
