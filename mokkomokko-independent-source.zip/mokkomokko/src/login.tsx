import {useEffect,useState,type FormEvent} from 'react';
import {useAuth} from './auth';
import {getBackend} from './backend';
export function ManageNav(){return <nav className="member-nav"><a className="back-link" href="/">← 모꼬모꼬 홈</a><a className="wordmark" href="/">MOKKOMOKKO<i>✳</i></a></nav>;}
export default function Login(){
 const auth=useAuth(),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[message,setMessage]=useState(''),[busy,setBusy]=useState(false),[setup,setSetup]=useState(false);
 useEffect(()=>{
  if(new URLSearchParams(location.search).get('setup')==='1'||/type=(recovery|invite)/.test(location.hash))setSetup(true);
  const sub=getBackend()?.auth.onAuthStateChange(event=>{if(event==='PASSWORD_RECOVERY')setSetup(true);});
  return ()=>sub?.data.subscription.unsubscribe();
 },[]);
 async function submit(e:FormEvent){
  e.preventDefault();const db=getBackend();if(!db||busy)return;setBusy(true);setMessage('');
  try{
   if(setup){const {error}=await db.auth.updateUser({password});if(error)throw error;setMessage('비밀번호를 설정했어요. 내 정보 관리로 이동해 주세요.');setSetup(false);await auth.refresh();}
   else{const {error}=await db.auth.signInWithPassword({email,password});if(error)throw error;location.assign('/manage/');}
  }catch{setMessage(setup?'초대 링크로 접속했는지 확인하고, 12자 이상 비밀번호를 입력해 주세요.':'이메일과 비밀번호를 확인해 주세요. 초대받은 멤버 계정으로 로그인할 수 있어요.');}
  finally{setBusy(false);}
 }
 async function recover(){
  const db=getBackend();if(!db||!email){setMessage('이메일을 먼저 입력해 주세요.');return;}setBusy(true);
  const {error}=await db.auth.resetPasswordForEmail(email,{redirectTo:location.origin+'/login/?setup=1'});
  setMessage(error?'메일을 보내지 못했어요. 잠시 후 다시 시도해 주세요.':'등록된 계정이라면 비밀번호 재설정 안내가 발송됩니다.');setBusy(false);
 }
 return <main className="manage-shell page-reveal"><ManageNav/><section className="access-card"><div className="section-kicker">MEMBERS ONLY · MOKKOMOKKO</div><div className="access-icon" aria-hidden="true">✳</div><h1>{setup?'나의 비밀번호 설정':'모꼬모꼬 멤버 로그인'}</h1>
 {!auth.ready?<p role="status">로그인을 준비하고 있어요.</p>:!auth.configured?<><p>멤버 로그인을 준비 중이에요.<br/>프로필과 앨범은 로그인 없이 구경할 수 있어요.</p><a className="solid-link" href="/">멤버 만나러 가기 ↗</a></>:auth.user&&!setup?<><p>{auth.user.email}</p><a className="solid-link" href="/manage/">내 정보 관리 ↗</a><button className="auth-text" onClick={async()=>{await getBackend()?.auth.signOut();await auth.refresh();}}>로그아웃</button></>:<>
 <p>{setup?'초대받은 계정에서 사용할 비밀번호를 정해 주세요.':'초대받은 네 멤버만 자신의 프로필과 앨범을 관리할 수 있어요.'}</p><form onSubmit={submit} className="auth-form">
 {!setup&&<label>이메일<input type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="초대받은 이메일"/></label>}
 <label>{setup?'새 비밀번호':'비밀번호'}<input type="password" required minLength={setup?12:1} maxLength={128} autoComplete={setup?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)}/></label>
 <button className="solid-link" disabled={busy} type="submit">{busy?'처리 중…':setup?'비밀번호 설정':'로그인 →'}</button></form>{!setup&&<button className="auth-text" disabled={busy} onClick={recover}>비밀번호를 잊었어요</button>}</>}
 {message&&<p className="form-message" role="status">{message}</p>}<a className="text-link" href="/">홈으로 돌아가기</a></section></main>;
}
