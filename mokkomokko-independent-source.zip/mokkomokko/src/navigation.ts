export function notFound():never{throw new Error('페이지를 찾을 수 없어요.');}
