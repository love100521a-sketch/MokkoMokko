import {useEffect,useState,type FormEvent} from 'react';
import {ArrowLeft,ChevronLeft,ChevronRight,Upload} from 'lucide-react';
import Image from './image';
import {getMember,type Member} from './lib/members';
import {getBackend} from './backend';
import {useAuth} from './auth';
type Art={id:string;url:string;title:string;artist:string;object_path?:string;sample?:boolean};
function publicArt(row:{id:string;object_path:string;title:string;artist:string}):Art{
 const db=getBackend()!;return {...row,url:db.storage.from('fanart').getPublicUrl(row.object_path).data.publicUrl};
}
export default function Album({slug}:{slug:string}){
 const member=getMember(slug)!;const style={'--member-color':member.color,'--member-soft':member.soft,'--member-ink':member.ink} as React.CSSProperties;
 return <main className="member-shell page-reveal" style={style}><nav className="member-nav" aria-label="앨범 탐색"><a className="back-link" href={`/members/${slug}/`}><ArrowLeft size={17}/>{member.name} 개인 페이지</a><a className="wordmark" href="/">MOKKOMOKKO<i>✳</i></a></nav><div className="album-layout"><div className="album-heading"><div><div className="micro-label">FAN ART ARCHIVE / {member.english}</div><h1>{member.name}의 앨범</h1></div><p>한 화면에 한 장씩, 다음 화면으로 넘겨 보세요.</p></div><AlbumBody key={slug} member={member}/></div></main>;
}
function AlbumBody({member}:{member:Member}){
 const auth=useAuth(),canEdit=auth.own===member.slug;
 const [uploaded,setUploaded]=useState<Art[]>([]),[index,setIndex]=useState(0),[turn,setTurn]=useState(0),[status,setStatus]=useState(''),[saving,setSaving]=useState(false);
 const items:Art[]=[...uploaded,{id:'basic-face',url:member.image,title:member.name+' 기본 얼굴',artist:'프로필 이미지',sample:true}];
 const current=Math.min(index,items.length-1),active=items[current];
 useEffect(()=>{
  let live=true;const db=getBackend();if(!db)return;
  db.from('artworks').select('id,object_path,title,artist').eq('member_slug',member.slug).order('created_at',{ascending:false}).then(({data,error})=>{
   if(!live)return;if(error){setStatus('앨범을 불러오지 못했어요. 잠시 후 다시 확인해 주세요.');return;}
   setUploaded((data??[]).map(publicArt));
  });return ()=>{live=false;};
 },[member.slug]);
 function move(next:number){if(next<0||next>=items.length)return;setIndex(next);setTurn(n=>n+1);}
 async function submit(e:FormEvent<HTMLFormElement>){
  e.preventDefault();if(saving||!canEdit)return;
  const db=getBackend();if(!db)return;
  const form=e.currentTarget,formData=new FormData(form),file=formData.get('image');
  if(!(file instanceof File)||!file.size){setStatus('이미지를 선택해 주세요.');return;}
  if(file.size>8*1024*1024){setStatus('8MB 이하 이미지만 올릴 수 있어요.');return;}
  const bytes=new Uint8Array(await file.slice(0,12).arrayBuffer());
  const png=bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71;
  const jpeg=bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
  const gif=String.fromCharCode(...bytes.slice(0,6)).match(/^GIF8[79]a$/);
  const webp=String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP';
  const ext=png?'png':jpeg?'jpg':gif?'gif':webp?'webp':null;
  if(!ext){setStatus('PNG, JPG, WEBP, GIF 이미지를 선택해 주세요.');return;}
  const mime=ext==='jpg'?'image/jpeg':`image/${ext}`;
  const title=String(formData.get('title')??'').trim(),artist=String(formData.get('artist')??'').trim();
  if(!title||!artist){setStatus('제목과 작가 이름을 입력해 주세요.');return;}
  setSaving(true);setStatus('');const id=crypto.randomUUID(),path=`${member.slug}/${id}.${ext}`;
  try{
   const result=await db.storage.from('fanart').upload(path,file,{contentType:mime,upsert:false});if(result.error)throw result.error;
   const row={id,member_slug:member.slug,object_path:path,title,artist};
   const inserted=await db.from('artworks').insert(row).select('id,object_path,title,artist').single();
   if(inserted.error){await db.storage.from('fanart').remove([path]);throw inserted.error;}
   setUploaded(prev=>[publicArt(inserted.data),...prev]);setIndex(0);setTurn(n=>n+1);form.reset();setStatus('앨범에 추가했어요!');
  }catch{setStatus('추가하지 못했어요. 내 멤버 계정과 연결 상태를 확인해 주세요.');}finally{setSaving(false);}
 }
 async function remove(){
  if(!canEdit||active.sample||saving||!confirm('이 이미지를 앨범에서 삭제할까요?'))return;
  const db=getBackend();if(!db)return;setSaving(true);setStatus('');
  try{
   const {data,error}=await db.from('artworks').delete().eq('id',active.id).select('id');
   if(error||!data?.length)throw error??new Error('permission');
   setUploaded(prev=>prev.filter(x=>x.id!==active.id));setIndex(0);setTurn(n=>n+1);
   const removed=await db.storage.from('fanart').remove([active.object_path!]);
   setStatus(removed.error?'앨범에서 삭제했어요. 원본 파일 정리는 운영자에게 문의해 주세요.':'앨범에서 삭제했어요.');
  }catch{setStatus('삭제하지 못했어요. 내 멤버 계정인지 확인해 주세요.');}finally{setSaving(false);}
 }
 return <div className="album-body"><div><div className="album-stage"><div className="album-stage-top"><span>ALBUM SCREEN</span><span>{String(current+1).padStart(2,'0')} / {String(items.length).padStart(2,'0')}</span></div><div key={turn} className="album-slide is-turning"><Image src={active.url} alt={active.title} fill/>{active.sample&&<span className="slide-watermark">기본 얼굴</span>}</div><div className="album-caption"><div><strong>{active.title}</strong><small>{active.artist}</small></div><span>{member.symbol}</span></div></div>
 <nav className="independent-pager" aria-label="앨범 페이지"><button className="page-btn" onClick={()=>move(current-1)} disabled={current===0}><ChevronLeft size={18}/> 이전 화면</button><span className="page-count" aria-live="polite">{current+1} / {items.length}</span><button className="page-btn" onClick={()=>move(current+1)} disabled={current===items.length-1}>다음 화면 <ChevronRight size={18}/></button></nav>
 {canEdit&&!active.sample&&<button className="delete-art" onClick={remove} disabled={saving}>현재 이미지 삭제</button>}<div className="album-thumbs" aria-label="앨범 이미지 목록">{items.map((item,i)=><button key={item.id} onClick={()=>move(i)} aria-label={`${i+1}번째 이미지: ${item.title}`} aria-current={current===i?'true':undefined}><Image src={item.url} alt="" fill/></button>)}</div><p role="status" aria-live="polite" className="form-message">{status}</p></div>
 <aside className="album-aside"><div className="micro-label">MEMBER ARCHIVE</div><h2>{canEdit?'내 앨범에 이미지 추가':'마음을 모아 둔 곳'}</h2><p>{canEdit?`${member.name}의 팬아트를 정리해 주세요. 작가 이름을 함께 남길 수 있어요.`:'이미지를 한 장씩 넘겨 보세요. 앨범 관리는 해당 멤버가 담당해요.'}</p>
 {canEdit?<form className="upload-form" onSubmit={submit}><label htmlFor="art-title">작품 제목</label><input id="art-title" name="title" maxLength={60} required/><label htmlFor="art-artist">작가 이름</label><input id="art-artist" name="artist" maxLength={40} required/><label htmlFor="art-image">이미지 선택</label><input id="art-image" name="image" type="file" accept="image/png,image/jpeg,image/webp,image/gif" required/><button className="solid-link" disabled={saving} type="submit"><Upload size={17}/>{saving?'처리 중…':'앨범에 추가'}</button></form>:<div className="album-viewer-note"><span>✦ VIEWING MODE</span><p>방문자는 로그인 없이 앨범을 구경할 수 있어요.</p><a className="outline-link" href={auth.user?'/manage/':'/login/'}>{auth.user?'내 정보 관리':'멤버 로그인 ↗'}</a></div>}
 <div className="sample-note">기본 얼굴은 첫 기록으로 남겨 두었어요. 팬아트는 멤버별로 모아 볼 수 있어요.</div></aside></div>;
}
