import {useEffect,useState} from 'react';
import {useAuth} from './auth';
import {getBackend} from './backend';
import {getMember} from './lib/members';
import {defaultProfile,validateProfile,type Profile} from './lib/profiles';
import {ManageNav} from './login';
import ProfileEditor from './profile-editor';
export default function Manage(){
 const auth=useAuth(),member=auth.own?getMember(auth.own):null;
 const [profile,setProfile]=useState<Profile|null>(null),[error,setError]=useState('');
 useEffect(()=>{
  let live=true;setProfile(null);setError('');
  const db=getBackend();if(!db||!auth.own)return;
  db.from('profiles').select('data').eq('slug',auth.own).maybeSingle().then(({data,error})=>{
   if(!live)return;if(error){setError('프로필을 불러오지 못했어요. 새로고침해 주세요.');return;}
   setProfile(validateProfile(data?.data)??defaultProfile(auth.own!));
  });return ()=>{live=false;};
 },[auth.own]);
 const style=member?{'--member-color':member.color,'--member-soft':member.soft,'--member-ink':member.ink} as React.CSSProperties:undefined;
 return <main className="manage-shell page-reveal" style={style}><ManageNav/>
 {!auth.ready?<section className="access-card"><h1>멤버 확인 중</h1><p role="status">잠시만 기다려 주세요.</p></section>:!auth.user?<section className="access-card"><div className="access-icon">✳</div><h1>우리의 작은 관리실</h1><p>{auth.configured?'초대받은 이메일로 로그인하면 자신의 프로필과 앨범을 관리할 수 있어요.':'멤버 로그인을 준비 중이에요. 공개 프로필과 앨범은 지금 구경할 수 있어요.'}</p><a className="solid-link" href={auth.configured?'/login/':'/'}>{auth.configured?'이메일로 로그인 →':'멤버 만나러 가기 →'}</a></section>:!member?<section className="access-card"><h1>아직 편집 권한이 없어요</h1><span className="account-label">{auth.user.email}</span><p>{auth.error||'이 계정에는 멤버가 연결되어 있지 않아요. 운영자가 해당 멤버의 권한을 연결하면 관리할 수 있어요.'}</p><a className="solid-link" href="/">모꼬모꼬 구경하기</a><button className="auth-text" onClick={()=>getBackend()?.auth.signOut()}>로그아웃</button></section>:<div className="manage-content"><div className="section-kicker">MY PLAYER ROOM · {member.english}</div><h1>{member.name}의 정보 관리</h1><span className="account-label">{auth.user.email}</span><p className="section-description manage-description">나의 프로필과 앨범을 이곳에서 관리해요.</p><div className="manage-links"><a href={`/members/${member.slug}/`}>내 소개 보기 ↗</a><a href={`/members/${member.slug}/album/`}>내 앨범 관리 ↗</a><button className="outline-link" onClick={()=>getBackend()?.auth.signOut()}>로그아웃</button></div>{error?<p role="alert">{error}</p>:profile?<ProfileEditor slug={member.slug} initial={profile}/>:<p role="status">프로필을 불러오는 중…</p>}</div>}
 </main>;
}
