-- Run once in the SQL editor of a NEW Supabase project for this website.
-- No accounts are created or granted access by this script.
begin;

create function public.valid_mokko_profile(v jsonb)
returns boolean language plpgsql immutable set search_path = pg_catalog as $$
declare k text; f jsonb;
begin
  if jsonb_typeof(v) is distinct from 'object' then return false; end if;
  foreach k in array array['intro','details','rp','mbti','likes','dislikes','broadcast','fandom','subscription','schedule','content','models','names','history'] loop
    if jsonb_typeof(v->k) is distinct from 'string' then return false; end if;
    if length(v->>k) > (case when k='history' then 12000 else 3000 end) then return false; end if;
  end loop;
  if length(btrim(v->>'intro'))=0 or length(btrim(v->>'rp'))=0 or length(btrim(v->>'mbti'))=0 then return false; end if;
  if jsonb_typeof(v->'facts') is distinct from 'array' then return false; end if;
  if jsonb_array_length(v->'facts')>20 then return false; end if;
  for f in select value from jsonb_array_elements(v->'facts') loop
    if jsonb_typeof(f) is distinct from 'object' or jsonb_typeof(f->'label') is distinct from 'string' or jsonb_typeof(f->'value') is distinct from 'string' then return false; end if;
    if length(f->>'label')>40 or length(f->>'value')>400 then return false; end if;
  end loop;
  return true;
end $$;

create table public.member_editors (
 user_id uuid primary key references auth.users(id) on delete cascade,
 member_slug text not null unique check(member_slug in ('kkongaji','momongtto','heundong','mimya')),
 created_at timestamptz not null default now()
);
create table public.profiles (
 slug text primary key check(slug in ('kkongaji','momongtto','heundong','mimya')),
 data jsonb not null check(public.valid_mokko_profile(data)),
 updated_at timestamptz not null default now()
);
create table public.artworks (
 id uuid primary key,
 member_slug text not null check(member_slug in ('kkongaji','momongtto','heundong','mimya')),
 object_path text not null unique,
 title text not null check(length(btrim(title)) between 1 and 60),
 artist text not null check(length(btrim(artist)) between 1 and 40),
 created_at timestamptz not null default now(),
 check(object_path ~ ('^' || member_slug || '/[0-9a-f-]{36}\.(png|jpg|gif|webp)$')),
 check(split_part(split_part(object_path,'/',2),'.',1)=id::text)
);
create index artworks_member_created on public.artworks(member_slug,created_at desc);
create function public.mokko_updated_at() returns trigger language plpgsql set search_path=pg_catalog as $$
begin new.updated_at=now(); return new; end $$;
create trigger profiles_updated before update on public.profiles for each row execute function public.mokko_updated_at();

alter table public.member_editors enable row level security;
alter table public.profiles enable row level security;
alter table public.artworks enable row level security;
revoke all on public.member_editors,public.profiles,public.artworks from anon,authenticated;
grant select on public.member_editors to authenticated;
grant select on public.profiles,public.artworks to anon,authenticated;
grant insert,update on public.profiles to authenticated;
grant insert,delete on public.artworks to authenticated;

create policy own_role_read on public.member_editors for select to authenticated using (user_id=(select auth.uid()));
-- There is deliberately NO client-side role INSERT/UPDATE/DELETE policy.
create policy public_profiles on public.profiles for select to anon,authenticated using(true);
create policy own_profile_insert on public.profiles for insert to authenticated with check(
 exists(select 1 from public.member_editors e where e.user_id=(select auth.uid()) and e.member_slug=slug)
);
create policy own_profile_update on public.profiles for update to authenticated using(
 exists(select 1 from public.member_editors e where e.user_id=(select auth.uid()) and e.member_slug=slug)
) with check(
 exists(select 1 from public.member_editors e where e.user_id=(select auth.uid()) and e.member_slug=slug)
);
create policy public_artworks on public.artworks for select to anon,authenticated using(true);
create policy own_art_insert on public.artworks for insert to authenticated with check(
 exists(select 1 from public.member_editors e where e.user_id=(select auth.uid()) and e.member_slug=artworks.member_slug)
);
create policy own_art_delete on public.artworks for delete to authenticated using(
 exists(select 1 from public.member_editors e where e.user_id=(select auth.uid()) and e.member_slug=artworks.member_slug)
);

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('fanart','fanart',true,8388608,array['image/png','image/jpeg','image/gif','image/webp']);
create policy mokko_fanart_insert on storage.objects for insert to authenticated with check(
 bucket_id='fanart' and exists(select 1 from public.member_editors e
 where e.user_id=(select auth.uid()) and e.member_slug=(storage.foldername(name))[1])
);
create policy mokko_fanart_delete on storage.objects for delete to authenticated using(
 bucket_id='fanart' and exists(select 1 from public.member_editors e
 where e.user_id=(select auth.uid()) and e.member_slug=(storage.foldername(name))[1])
);
create policy mokko_fanart_editor_read on storage.objects for select to authenticated using(
 bucket_id='fanart' and exists(select 1 from public.member_editors e
 where e.user_id=(select auth.uid()) and e.member_slug=(storage.foldername(name))[1])
);
commit;
