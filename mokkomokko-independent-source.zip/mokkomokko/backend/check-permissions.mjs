// Disposable local PostgreSQL test. No real accounts, invitations, or services.
import {PGlite} from '@electric-sql/pglite';
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
process.on('uncaughtException',error=>{console.error(JSON.stringify({message:error.message,position:error.position,internalPosition:error.internalPosition,internalQuery:error.internalQuery,where:error.where}));process.exit(1);});
const db=new PGlite();let checks=0;const results=[];
await db.exec(`
 create role anon; create role authenticated;
 create schema auth; create schema storage;
 grant usage on schema public,auth,storage to anon,authenticated;
 create table auth.users(id uuid primary key);
 create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
 create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 create table storage.objects(id bigint generated always as identity primary key,bucket_id text,name text);
 alter table storage.objects enable row level security;
 grant select,insert,delete on storage.objects to authenticated;
 grant usage,select on sequence storage.objects_id_seq to authenticated;
 create function storage.foldername(text) returns text[] language sql immutable as $$select (string_to_array($1,'/'))[1:array_length(string_to_array($1,'/'),1)-1]$$;
`);
await db.exec(await readFile('backend/01-schema.sql','utf8'));
const slugs=['kkongaji','momongtto','heundong','mimya'];
const uid=i=>`00000000-0000-4000-8000-${String(i+1).padStart(12,'0')}`;
const profile={intro:'테스트 소개',details:'내용',rp:'역할',mbti:'INFP',facts:[{label:'생일',value:'테스트'}],likes:'',dislikes:'',broadcast:'',fandom:'',subscription:'',schedule:'',content:'',models:'',names:'',history:''};
async function ok(label,fn){await fn();checks++;results.push(label);}
async function denied(label,fn){let blocked=false;try{await fn();}catch{blocked=true;}assert.ok(blocked,label);checks++;results.push(label);}
async function asUser(i){await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[i===null?'':uid(i)]);await db.exec('set role '+(i===null?'anon':'authenticated'));}
await ok('Initial editor table is empty',async()=>assert.equal((await db.query('select count(*)::int n from public.member_editors')).rows[0].n,0));
for(let i=0;i<5;i++)await db.query('insert into auth.users(id) values($1)',[uid(i)]);
for(let i=0;i<4;i++)await db.query('insert into public.member_editors(user_id,member_slug) values($1,$2)',[uid(i),slugs[i]]);
await denied('Fifth editor cannot use a fifth member slug',()=>db.query('insert into public.member_editors(user_id,member_slug) values($1,$2)',[uid(4),'outsider']));
await denied('A member cannot have a second editor',()=>db.query('insert into public.member_editors(user_id,member_slug) values($1,$2)',[uid(4),'kkongaji']));
await asUser(null);
await denied('Guest cannot create a profile',()=>db.query('insert into public.profiles(slug,data) values($1,$2)',[slugs[0],profile]));
await asUser(4);
await denied('Unassigned account cannot create a profile',()=>db.query('insert into public.profiles(slug,data) values($1,$2)',[slugs[0],profile]));
await denied('Unassigned account cannot grant itself a role',()=>db.query('insert into public.member_editors(user_id,member_slug) values($1,$2)',[uid(4),'kkongaji']));
for(let i=0;i<4;i++){
 await asUser(i);
 await ok(`${slugs[i]} editor can insert own profile`,()=>db.query('insert into public.profiles(slug,data) values($1,$2)',[slugs[i],profile]));
 await ok(`${slugs[i]} editor can update own profile`,async()=>assert.equal((await db.query("update public.profiles set data=jsonb_set(data,'{intro}','\"저장됨\"') where slug=$1 returning slug",[slugs[i]])).rows.length,1));
 await ok(`${slugs[i]} editor sees only own role`,async()=>assert.equal((await db.query('select * from public.member_editors')).rows.length,1));
}
await asUser(null);
await ok('Guest can read all four public profiles',async()=>assert.equal((await db.query('select * from public.profiles')).rows.length,4));
await asUser(0);
await ok('Cross-member update affects no rows',async()=>assert.equal((await db.query("update public.profiles set data=jsonb_set(data,'{intro}','\"공격\"') where slug='mimya' returning slug")).rows.length,0));
await denied('Moving own profile to another member is blocked',()=>db.exec("update public.profiles set slug='mimya' where slug='kkongaji'"));
await denied('Editing role assignments is blocked',()=>db.exec("update public.member_editors set member_slug='mimya'"));
await denied('Invalid JSON profile is rejected by database',()=>db.query("update public.profiles set data=$1 where slug='kkongaji'",[{intro:'bad'}]));
await denied('Oversized field is rejected by database',()=>db.query("update public.profiles set data=$1 where slug='kkongaji'",[{...profile,details:'a'.repeat(3001)}]));
const aid='10000000-0000-4000-8000-000000000001',object=`kkongaji/${aid}.png`;
await ok('Own album metadata insert allowed',()=>db.query('insert into public.artworks(id,member_slug,object_path,title,artist) values($1,$2,$3,$4,$5)',[aid,'kkongaji',object,'그림','작가']));
await ok('Own storage folder upload allowed',()=>db.query("insert into storage.objects(bucket_id,name) values('fanart',$1)",[object]));
await denied('Other member storage folder upload denied',()=>db.query("insert into storage.objects(bucket_id,name) values('fanart',$1)",[`mimya/${aid}.png`]));
await denied('Other member album metadata insert denied',()=>db.query('insert into public.artworks(id,member_slug,object_path,title,artist) values($1,$2,$3,$4,$5)',['20000000-0000-4000-8000-000000000002','mimya','mimya/20000000-0000-4000-8000-000000000002.png','그림','작가']));
await asUser(3);
await ok('Other editor cannot delete album metadata',async()=>assert.equal((await db.query('delete from public.artworks where id=$1 returning id',[aid])).rows.length,0));
await ok('Other editor cannot delete storage object',async()=>assert.equal((await db.query('delete from storage.objects where name=$1 returning id',[object])).rows.length,0));
await asUser(null);
await ok('Guest can read album metadata',async()=>assert.equal((await db.query('select * from public.artworks')).rows.length,1));
await asUser(0);
await ok('Owner can delete own album metadata',async()=>assert.equal((await db.query('delete from public.artworks where id=$1 returning id',[aid])).rows.length,1));
await ok('Owner can delete own storage object',async()=>assert.equal((await db.query('delete from storage.objects where name=$1 returning id',[object])).rows.length,1));
await db.close();
const report={passed:checks,engine:'PGlite PostgreSQL; Supabase auth/storage schemas simulated locally',realAccountsOrInvitations:0,checks:results};
await writeFile('backend/permission-check-results.json',JSON.stringify(report,null,2)+'\n');
console.log(`PASS ${checks} PostgreSQL permission checks. No live accounts created.`);
