-- TEMPLATE ONLY. Do not run until the user has chosen and confirmed FOUR emails.
-- 1. Disable public signup in Authentication settings.
-- 2. Invite each confirmed email in Supabase Authentication > Users.
--    Set redirect URL to https://YOUR-ACTUAL-DOMAIN/login/?setup=1
-- 3. Verify each account's UUID in Authentication > Users.
-- 4. Replace UUID placeholders below, uncomment the INSERT, and run as project owner.
-- A user can own ONE member, and a member can have ONE editor (four maximum).

-- insert into public.member_editors(user_id,member_slug) values
-- ('REPLACE-WITH-KKONGAJI-USER-UUID','kkongaji'),
-- ('REPLACE-WITH-MOMONGTTO-USER-UUID','momongtto'),
-- ('REPLACE-WITH-HEUNDONG-USER-UUID','heundong'),
-- ('REPLACE-WITH-MIMYA-USER-UUID','mimya');

-- To revoke one confirmed account later, run as owner:
-- delete from public.member_editors where member_slug='CONFIRMED-SLUG';
-- Never give browser clients service_role or secret API keys.
