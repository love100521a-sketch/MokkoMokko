# 모꼬모꼬 독립형 홈페이지

꽁아지 · 모몽또 · 흰동 · 밈먀의 소개와 팬아트 앨범을 담은 별도 호스팅용 제작본입니다.
사이트 이름은 **모꼬모꼬**, 영문 프로젝트 이름은 **mokkomokko**입니다.
ChatGPT 로그인이나 ChatGPT 호스팅이 필요하지 않습니다.

현재 제작본은 업로드 전입니다. 새 인터넷 주소는 아직 발급되지 않았습니다.
기존 홈페이지는 그대로 유지됩니다. 이 파일을 만들면서 기존 사이트를 변경하지 않았습니다.

## 먼저 볼 파일

- `mokkomokko-preview.html`: 파일을 브라우저로 열면 메인 → 멤버 → 앨범을 미리 볼 수 있습니다. 얼굴 4장과 시그니처 8장은 파일 안에 들어 있습니다. 이 파일은 공개 사이트 주소가 아닙니다.
- `mokkomokko-upload.zip`: **이 ZIP 자체를 Cloudflare Pages에 올리면 됩니다.** ZIP 내부의 최상위에 `index.html`이 있습니다. 소스 전체 ZIP을 대신 올리지 마세요.
- `site/`: 실제 배포할 파일들입니다.
- `backend/`: 멤버 로그인, 수정 권한, 앨범 저장을 연결할 Supabase SQL입니다.

## 1. 우선 홈페이지 주소부터 만들기

멤버 편집 설정을 하기 전에도, 방문자가 보는 프로필과 기본 앨범은 공개할 수 있습니다.

1. Cloudflare에 로그인합니다. https://dash.cloudflare.com/
2. **Workers & Pages**에서 **Create application**을 누릅니다.
3. **Pages**의 파일 업로드 만들기(**Drag and drop files**)를 선택합니다. Workers 코드 편집 화면이 나오면 Pages 만들기로 돌아가세요.
4. 프로젝트 이름에 `mokkomokko`를 입력합니다.
5. `mokkomokko-upload.zip`을 업로드하고 **Deploy site**를 누릅니다.
6. 완료 화면에 실제 발급된 주소가 표시됩니다. 그 주소를 사용하세요.

주소 형태는 `프로젝트이름.pages.dev`입니다. `mokkomokko.pages.dev`는 희망 주소이며 현재 예약하거나 발급한 주소가 아닙니다. 이미 사용 중인 이름이면 Cloudflare가 다른 이름이나 접미사를 요구할 수 있습니다. `mokkomokko-crew` 또는 `mokkomokko-club`도 후보입니다.

주소창에는 숫자 IP 대신 이름이 표시됩니다. 도메인으로 접속하더라도 서버의 IP를 기술적으로 조회할 수 없게 만드는 것은 아닙니다. 개인 PC를 서버로 공개하는 방식은 사용하지 않습니다.

현재 Cloudflare 공식 업로드 안내: https://developers.cloudflare.com/pages/get-started/direct-upload/

## 2. 멤버 편집 기능 연결하기

지금은 연결 정보와 편집 계정이 **모두 비어 있습니다.** 누구에게도 권한을 발급하지 않았습니다.
로그인 없이 볼 수 있는 공개 프로필은 이미 파일에 들어 있고, 연결 후 수정한 내용은 데이터베이스에서 읽습니다.

1. Supabase에서 이 사이트 전용 새 프로젝트를 만듭니다. https://supabase.com/dashboard
2. 프로젝트의 **SQL Editor**에서 `backend/01-schema.sql`의 내용을 한 번 실행합니다.
3. **Authentication** 설정에서 일반 사용자 신규 가입을 비활성화합니다. 이메일 로그인은 유지합니다. 초대받지 않은 계정은 편집할 수 없도록 데이터베이스 정책도 별도로 적용되어 있습니다.
4. **URL Configuration**에서 Site URL을 1단계에서 발급된 실제 주소로 설정하고, Redirect URLs에 `실제주소/login/`와 `실제주소/login/?setup=1`을 허용합니다.
5. 프로젝트의 **API Keys**에서 Project URL과 **Publishable key**를 확인합니다. `sb_publishable_...` 키를 사용하세요. 예전 프로젝트는 공개 `anon` 키도 지원합니다.
6. `site/site-config.js`를 텍스트 편집기로 열어 다음 두 값만 입력합니다. **secret 키, service_role 키, 비밀번호는 입력하지 마세요.**

```js
window.MOKKOMOKKO_CONFIG = {
  supabaseUrl: "https://자신의프로젝트.supabase.co",
  supabasePublishableKey: "sb_publishable_자신의공개키"
};
```

7. `site` 폴더의 **내용물**을 ZIP으로 묶고 기존 Cloudflare Pages 프로젝트에 새 배포로 업로드합니다. 코드 빌드는 다시 하지 않아도 됩니다.

일반적인 Supabase 프로젝트 주소를 기준으로 보안 헤더가 작성되어 있습니다. 별도 Supabase 사용자 도메인을 설정하면 `site/_headers`의 `connect-src`에도 실제 API 도메인을 추가해야 합니다.

## 3. 네 멤버 계정 연결은 이메일이 정해진 뒤에

현재는 아무도 초대하지 마세요. 네 멤버의 실제 이메일이 확정되고 본인 확인이 끝난 뒤에만 진행합니다.

1. Supabase **Authentication → Users**에서 확정된 계정들을 초대합니다. 이메일 발송 설정이 필요하면 Supabase의 SMTP 안내를 따릅니다.
2. 초대 링크의 redirect를 `실제주소/login/?setup=1`로 설정합니다.
3. 각 멤버가 초대 메일로 들어와 자기 비밀번호를 설정합니다. 비밀번호를 운영자나 채팅으로 전달할 필요가 없습니다.
4. 운영자가 Users 화면의 계정 UUID를 확인하고 `backend/02-grant-template.sql`의 해당 자리와 정확히 연결합니다.
5. 권한을 연결한 뒤에는 `/manage/`에서 자기 프로필과 자기 앨범만 수정할 수 있습니다. 다른 멤버의 역할로 바꾸는 버튼은 없으며, 직접 요청을 바꾸더라도 데이터베이스가 거부합니다.

하나의 계정은 한 멤버만, 한 멤버는 한 계정만 가질 수 있습니다. 가능한 멤버는 네 명으로 제한되어 있습니다.

## 반영된 내용

- 휴대용 게임기 형태의 모꼬모꼬 메인과 멤버별 시그니처 색상
- 각 멤버 개인 페이지, 이전·다음 멤버 이동, 별도 팬아트 앨범
- 기존 기본 얼굴 4장 유지, 두 번째 체험 이미지는 제외
- 꽁아지 상세 프로필과 방송·활동 기록
- 구독티콘 아래 클릭해 확대하고 이전·다음으로 넘기는 시그니처 8장
- 일반 이메일 로그인과 멤버별 프로필 수정 폼
- 본인 앨범만 업로드·삭제, 제목과 작가 이름, 8MB 이하 PNG/JPG/GIF/WEBP 지원
- 방문자 전체 읽기, 멤버 역할 자체 발급·교체는 운영자만 가능
- 일반 도메인에 배포할 수 있는 정적 HTML/CSS/JS. ChatGPT 사이트 전용 서버와 로그인 코드는 포함하지 않음

프로필과 시그니처·얼굴은 로컬 파일로 포함되어 있습니다. 구독티콘 원본은 사용자가 제공한 SOOP 이미지 주소를 이용하므로 해당 이미지가 표시되려면 인터넷 연결이 필요합니다.

## 개발자가 소스를 수정할 경우

Node.js 22 이상에서 실행합니다.

```bash
npm ci
npm run check
npm run build
node backend/check-permissions.mjs
npm run preview
```

로컬 테스트 서버는 4173번 포트입니다. `site/`를 배포합니다. 미리보기를 새로 만들려면 `node build-preview.mjs`를 실행합니다. 원본 CSS는 배포에 맞게 미리 컴파일되어 있어 서버에서 추가 빌드 도구를 실행할 필요가 없습니다.

## 검증 범위

TypeScript 검사와 정적 빌드, 11개 페이지의 내부 링크·자산 경로 검사를 통과했습니다. PostgreSQL 기반의 로컬 격리 데이터베이스에서 권한 검사 33개를 통과했습니다. 테스트용 계정 ID만 사용했고 실제 서비스 계정 생성이나 초대는 하지 않았습니다.

아직 외부 호스팅과 Supabase 프로젝트가 연결되지 않았으므로 실제 도메인 접속, 이메일 수신, 운영 서버 로그인·저장·업로드는 배포 후 확인해야 합니다. 이 실행 환경의 브라우저에서는 로컬 테스트 서버에 연결되지 않아 브라우저 시각 검증을 완료하지 못했습니다. 배포 후 휴대폰과 PC에서 확인해 주세요.
