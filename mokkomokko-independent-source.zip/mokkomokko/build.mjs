import {build} from 'esbuild';
import {mkdir,writeFile,readFile,copyFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {createElement} from 'react';
import {renderToString} from 'react-dom/server';
const aliases={'@':new URL('./src',import.meta.url).pathname,'next/image':new URL('./src/image.tsx',import.meta.url).pathname,'next/navigation':new URL('./src/navigation.ts',import.meta.url).pathname};
await mkdir('site/assets',{recursive:true});
await mkdir('.build',{recursive:true});
await build({entryPoints:['src/client.tsx'],bundle:true,minify:true,format:'esm',target:['es2022'],outfile:'site/assets/app.js',alias:aliases,define:{'process.env.NODE_ENV':'"production"'},jsx:'automatic',legalComments:'eof'});
await build({entryPoints:['src/app.tsx'],bundle:true,platform:'node',format:'esm',outfile:'.build/ssr.mjs',alias:aliases,packages:'external',jsx:'automatic'});
const {App}=await import(pathToFileURL(new URL('./.build/ssr.mjs',import.meta.url).pathname));
const routes=[['/','모꼬모꼬 | 우리의 작은 놀이터']];
const roster=[['kkongaji','꽁아지'],['momongtto','모몽또'],['heundong','흰동'],['mimya','밈먀']];
for(const [slug,name] of roster){routes.push([`/members/${slug}/`,`${name}의 개인 페이지 | 모꼬모꼬`],[`/members/${slug}/album/`,`${name}의 팬아트 앨범 | 모꼬모꼬`]);}
routes.push(['/login/','멤버 로그인 | 모꼬모꼬'],['/manage/','내 정보 관리 | 모꼬모꼬']);
function document(path,title){
 const markup=renderToString(createElement(App,{path}));
 return `<!doctype html><html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#f267a0"><title>${title}</title><meta name="description" content="꽁아지, 모몽또, 흰동, 밈먀. 네 가지 색과 네 가지 이야기가 모인 모꼬모꼬의 작은 놀이터."><meta property="og:title" content="${title}"><meta property="og:description" content="네 가지 색, 네 가지 이야기. 모꼬모꼬 멤버들의 프로필과 팬아트 앨범을 만나보세요."><meta property="og:type" content="website"><link rel="icon" href="/favicon.svg"><link rel="stylesheet" href="/assets/styles.css"><link rel="stylesheet" href="/assets/independent.css"><script src="/site-config.js"></script><script type="module" src="/assets/app.js"></script></head><body><a href="#app" class="skip-link">본문으로 바로가기</a><div id="app">${markup}</div><noscript><p class="noscript-note">프로필은 지금 읽을 수 있어요. 앨범 넘기기와 멤버 관리는 JavaScript를 켜 주세요.</p></noscript></body></html>`;
}
for(const [path,title] of routes){const dir='site'+path;await mkdir(dir,{recursive:true});await writeFile(dir+'index.html',document(path,title));}
await writeFile('site/404.html',document('/404/','페이지를 찾을 수 없어요 | 모꼬모꼬'));
console.log(`Built ${routes.length} pages and 404, with local browser assets.`);
