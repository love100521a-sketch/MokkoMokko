// Public settings only. Never put a secret key, service_role key, or password here.
// Empty settings leave the public site working with member editing disabled.
window.MOKKOMOKKO_CONFIG = {
  supabaseUrl: "",
  supabasePublishableKey: ""
};
